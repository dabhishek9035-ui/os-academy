"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useSystemStore } from "@/lib/commands/system-store";
import { processColor } from "@/types";
import type { SimProcess } from "@/modules/processes/engine";

/**
 * The 3D "system landscape" — an abstract, data-driven scene (per the
 * immersive-3d-web skill: abstract primitives are appropriate here; no
 * recognisable objects are faked from boxes).
 *
 * Read-only consumer of the shared simulation store: the 2D labs remain the
 * source of truth. Per-frame values are eased in useFrame; React state only
 * carries low-frequency changes. Ambient motion period ≈ 12 s; everything
 * freezes under reduced motion (timeScale → 0).
 */

const SYSTEM_RADIUS = 4.2;

function eased(current: number, target: number, dt: number, speed = 4): number {
  return current + (target - current) * (1 - Math.exp(-dt * speed));
}

/** Central glowing core = the CPU. Pulses with scheduling activity. */
function CpuCore({ busy }: { busy: boolean }) {
  const mesh = useRef<THREE.Mesh>(null);
  const halo = useRef<THREE.Mesh>(null);
  const t = useRef(0);
  useFrame((_, dt) => {
    t.current += dt;
    if (mesh.current) {
      mesh.current.rotation.y += dt * 0.4;
      const target = busy ? 1.18 : 1.0;
      const s = eased(mesh.current.scale.x, target, dt, 6);
      mesh.current.scale.setScalar(s);
    }
    if (halo.current) {
      const mat = halo.current.material as THREE.MeshBasicMaterial;
      mat.opacity = 0.16 + 0.1 * Math.sin(t.current * 1.5);
    }
  });
  return (
    <group>
      <mesh ref={mesh}>
        <icosahedronGeometry args={[1.1, 2]} />
        <meshStandardMaterial
          color="#22d3ee"
          emissive="#0891b2"
          emissiveIntensity={0.9}
          roughness={0.25}
          metalness={0.1}
        />
      </mesh>
      <mesh ref={halo} scale={1.9}>
        <sphereGeometry args={[1.1, 24, 24]} />
        <meshBasicMaterial color="#0ea5e9" transparent opacity={0.18} />
      </mesh>
    </group>
  );
}

/** One orb per live process, arranged on a ring. Height = progress. */
function ProcessOrb({ proc, index, total }: { proc: SimProcess; index: number; total: number }) {
  const group = useRef<THREE.Group>(null);
  const targetY = useMemo(() => (proc.progress / Math.max(1, proc.burst)) * 2.2, [proc.progress, proc.burst]);
  const angle = (index / Math.max(1, total)) * Math.PI * 2;
  useFrame((state, dt) => {
    if (!group.current) return;
    const targetX = Math.cos(angle + state.clock.elapsedTime * 0.08) * SYSTEM_RADIUS;
    const targetZ = Math.sin(angle + state.clock.elapsedTime * 0.08) * SYSTEM_RADIUS;
    group.current.position.x = eased(group.current.position.x, targetX, dt, 2.2);
    group.current.position.z = eased(group.current.position.z, targetZ, dt, 2.2);
    group.current.position.y = eased(group.current.position.y, targetY, dt, 3);
  });
  const color = new THREE.Color(processColor(index));
  const zombie = proc.state === "zombie";
  const blocked = proc.state === "blocked";
  return (
    <group ref={group}>
      <mesh>
        <sphereGeometry args={[0.42, 28, 28]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={zombie ? 0.15 : blocked ? 0.3 : 0.7}
          roughness={0.35}
          transparent
          opacity={proc.state === "terminated" ? 0.25 : 1}
        />
      </mesh>
      {(zombie || blocked) && (
        <mesh scale={1.5}>
          <sphereGeometry args={[0.42, 16, 16]} />
          <meshBasicMaterial
            color={zombie ? "#a78bfa" : "#fbbf24"}
            transparent
            opacity={0.22}
            wireframe
          />
        </mesh>
      )}
    </group>
  );
}

/** Ground grid + slow fog — the "landscape" layer. */
function Landscape({ spin }: { spin: boolean }) {
  const grid = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (grid.current && spin) grid.current.rotation.y += dt * 0.03;
  });
  return (
    <group ref={grid}>
      <gridHelper args={[16, 24, "#1c2436", "#10141f"]} position={[0, -2.2, 0]} />
      {/* disk monolith */}
      <mesh position={[-5.4, -1.1, -2.4]}>
        <boxGeometry args={[1.4, 2.2, 1.4]} />
        <meshStandardMaterial color="#2b3348" roughness={0.6} metalness={0.35} />
      </mesh>
      {/* RAM bars */}
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[5.4 - i * 0.0, -1.6 + i * 0.55, -2.4 - i * 0.9]}>
          <boxGeometry args={[1.5, 0.28, 0.7]} />
          <meshStandardMaterial
            color="#818cf8"
            emissive="#4f46e5"
            emissiveIntensity={0.35}
            roughness={0.4}
          />
        </mesh>
      ))}
    </group>
  );
}

function Rig({ reduced }: { reduced: boolean }) {
  useFrame((state) => {
    if (reduced) return;
    // Slow autonomous orbit + gentle mouse parallax.
    const t = state.clock.elapsedTime;
    const r = 9.5;
    state.camera.position.x = eased(
      state.camera.position.x,
      Math.sin(t * 0.05) * r * 0.35 + state.pointer.x * 0.9,
      0.016,
      1.4,
    );
    state.camera.position.y = eased(state.camera.position.y, 3.4 + state.pointer.y * 0.5, 0.016, 1.4);
    state.camera.position.z = eased(state.camera.position.z, r, 0.016, 1.4);
    state.camera.lookAt(0, 0.4, 0);
  });
  return null;
}

export function SystemScene({ reduced, tier }: { reduced: boolean; tier: "high" | "medium" | "low" }) {
  const processes = useSystemStore((s) => s.processes.processes);
  const runningPid = useSystemStore((s) => s.processes.runningPid);
  const live = useMemo(
    () => processes.filter((p) => p.state !== "terminated").slice(0, 8),
    [processes],
  );
  const dpr = tier === "high" ? 1.75 : tier === "medium" ? 1.25 : 1;

  return (
    <Canvas
      dpr={dpr}
      camera={{ position: [0, 3.4, 9.5], fov: 50 }}
      gl={{ antialias: tier !== "low", alpha: true }}
      style={{ pointerEvents: "none" }}
      aria-hidden
    >
      <color attach="background" args={["#080a10"]} />
      <fog attach="fog" args={["#080a10", 10, 26]} />
      <ambientLight intensity={0.5} />
      <directionalLight position={[4, 6, 3]} intensity={1.1} color="#cfe9ff" />
      <pointLight position={[0, 1.5, 0]} intensity={2.2} color="#22d3ee" distance={9} />
      <Rig reduced={reduced} />
      <CpuCore busy={runningPid !== null} />
      {live.map((p, i) => (
        <ProcessOrb key={p.pid} proc={p} index={i} total={live.length} />
      ))}
      <Landscape spin={!reduced} />
    </Canvas>
  );
}
